<?php
$licenses = [
    "civ" => [
		['driver',"Führerschein"],
		['boat',"Bootsschein"],
		['pilot',"Pilotenschein"],
		['trucking',"LkwSchein"],
		['gun',"Waffenschein"],
		['dive',"Tauchschein"],
		['home',"Eigtümerurkunde"],
		['oil',"Ölverarbeitung"],
		['diamond',"Diamantenverarbeitung"],
		['salt',"Salzverabeitung"],
		['sand',"Glasherstellung"],
		['iron',"Eisenverarbeitun"],
		['copper',"kupferverarbeitung"],
		['cement',"zementherstellung"],
		['medmarijuana',"medweed"],
		['cocaine',"kokainherstellung"],
		['heroin',"herionverarbeitung"],
		['marijuana',"mariuhannaverarbeitung"],
		['rebel',"Rebellenurkunde"],
		['Tabak',"Tabakverarbeitung"]

    ],
    "med" => [
		['license_med_mAir',"Flugausbildung"],
		['license_med_mGa',"Grundausbildung"],
		['license_med_mRP',"Roleplayausbildung"],
		['license_med_mDT',"Doktortest"],
		['license_med_mFA',"Funkausbildung"],
		['license_med_cg',"Schwimmschein"]
    ],
    "cop" => [
		['license_cop_cAir',"Flugausbildung"],
		['license_cop_cGa',"Grundausbildung"],
		['license_cop_cRP',"Roleplayausbildung"],
		['license_cop_cKuT',"Kampf und Taktik"],
		['license_cop_cFA',"Funkausbildung"],
		['license_cop_cg',"Schwimmschein"]
  ],

];



?>
