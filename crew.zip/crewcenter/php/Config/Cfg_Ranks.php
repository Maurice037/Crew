<?php


$ranks = [
	'med' => [
		'nicht eingestellt',
		'Praktikant',
		'Auszubildener',
		'Rettungsassistent',
		'Rettungssanitäter',
		'Rettungspilot',
		'Assistentsarzt',
		'Oberarzt',
		'Chefarzt',
		'Ausbilder',
		'Vorstand'
	],
	'cop' => [
		'nicht eingestellt',
		'Praktikant',
		'Anwärter',
		'Meister',
		'Obermeister',
		'Hauptmeister',
		'Kommissar',
		'Oberkommissar',
		'Hauptkommissar',
		'Ausbilder',
		'Leitung'
	],
	'sek' => [
		'nicht eingestellt',
		'Anwärter',
		'Beamter',
		'Geheimdienst',
		'Leitung',
	],
	'admin' => [
		'nicht im Team', 
		'Pate',
		'Wächter',
		'Entwickler',
		'Entwicklerleitung',
		'Supporter',
		'moderator',
		'SupportLeitung',
		'ModeratorLeitung',
		'Admin',
		'Projektleitung'

	]
];

?>
